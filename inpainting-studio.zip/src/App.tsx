import React, { useState, useRef } from 'react';
import { Upload, ArrowRight, RefreshCw, Loader2, Plus, Image as ImageIcon, X } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';

type Item = {
  id: number;
  image: string | null;
  label: string;
};

export default function App() {
  const [imageModel, setImageModel] = useState<string | null>(null);
  const [items, setItems] = useState<Item[]>([
    { id: 1, image: null, label: '' },
    { id: 2, image: null, label: '' }
  ]);
  const [outputImage, setOutputImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const fileInputModelRef = useRef<HTMLInputElement>(null);
  const fileInputItemRefs = useRef<(HTMLInputElement | null)[]>([]);

  const handleModelFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setImageModel(reader.result as string);
      reader.readAsDataURL(file);
    }
    e.target.value = '';
  };

  const handleItemFileChange = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const newItems = [...items];
        newItems[index].image = reader.result as string;
        setItems(newItems);
      };
      reader.readAsDataURL(file);
    }
    e.target.value = '';
  };

  const handleRemoveItem = (index: number) => {
    const newItems = [...items];
    newItems[index].image = null;
    newItems[index].label = '';
    setItems(newItems);
  };

  const handleLabelChange = (index: number, label: string) => {
    const newItems = [...items];
    newItems[index].label = label;
    setItems(newItems);
  };

  const handleGenerate = async () => {
    const validItems = items.filter(item => item.image && item.label.trim() !== '');
    
    if (!imageModel) {
      setError('Vui lòng tải lên ảnh người mẫu gốc.');
      return;
    }
    if (validItems.length === 0) {
      setError('Vui lòng tải lên ít nhất 1 món đồ và nhập mô tả.');
      return;
    }

    setIsLoading(true);
    setError('');
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      
      const base64Model = imageModel.split(',')[1];
      const mimeModel = imageModel.split(',')[0].split(':')[1].split(';')[0];
      
      let itemsDescription = validItems.map((item, idx) => `Item ${idx + 1} (mô tả: ${item.label})`).join('\n');

      const prompt = `VAI TRÒ:
Bạn là một AI Inpainting chuyên nghiệp, hoạt động dựa trên câu lệnh điều khiển của người dùng. Nhiệm vụ của bạn là thực hiện thay đổi trên ảnh gốc.

QUY TRÌNH XỬ LÝ:
1. Ưu tiên thực hiện lệnh trong label_1 cho Item 1.
2. Sau đó thực hiện tiếp lệnh trong label_2 cho Item 2 lên cùng một bức ảnh.
3. Nếu chỉ có 1 item được tải lên, chỉ thực hiện lệnh tương ứng.

THÔNG TIN ĐẦU VÀO:
${itemsDescription}
(Các hình ảnh vật phẩm được cung cấp theo thứ tự tương ứng sau ảnh gốc).

CƠ CHẾ XỬ LÝ THEO CÂU LỆNH (COMMAND-DRIVEN):
Bạn phải đọc kỹ văn bản trong ô label và hành động theo các từ khóa sau:
1. "Thay/Thay thế": Tìm vùng đồ vật cũ trong ảnh gốc và ghi đè hoàn toàn bằng vật phẩm mới. Phải xóa sạch dấu vết đồ cũ.
2. "Thêm/Đeo thêm/Khoác thêm": Giữ nguyên quần áo hiện có, chỉ vẽ thêm vật phẩm mới vào vị trí hợp lý (ví dụ: túi xách vào tay, đồng hồ vào cổ tay).
3. "Chỉnh/Sửa": Thay đổi một chi tiết nhỏ (ví dụ: đổi màu, thêm họa tiết) dựa trên vật phẩm được cung cấp.

RÀNG BUỘC KỸ THUẬT SIÊU CẤP:
- Ưu tiên Câu lệnh: Nếu người dùng ghi "Thay váy", bạn CẤM được mặc chồng váy mới lên váy cũ. Nếu người dùng ghi "Giữ nguyên bối cảnh", bạn CẤM được thay đổi dù chỉ 1 pixel ở hậu trường.
- Bảo tồn Identity: Giữ nguyên 100% khuôn mặt, ánh mắt, điện thoại và vóc dáng người mẫu.
- Tính tự nhiên: Vật phẩm mới phải có độ đổ bóng và ánh sáng hòa hợp hoàn toàn với môi trường trong ảnh mẫu gốc.`;

      const parts: any[] = [
        { inlineData: { data: base64Model, mimeType: mimeModel } }
      ];

      validItems.forEach(item => {
         const base64Item = item.image!.split(',')[1];
         const mimeItem = item.image!.split(',')[0].split(':')[1].split(';')[0];
         parts.push({ inlineData: { data: base64Item, mimeType: mimeItem } });
      });

      parts.push({ text: prompt });

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: { parts },
      });

      let outImage = '';
      for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
          outImage = `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
          break;
        }
      }
      
      if (outImage) {
        setOutputImage(outImage);
      } else {
        setError('Không thể tạo ảnh. Vui lòng thử lại.');
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Đã xảy ra lỗi trong quá trình xử lý.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleUseAsNextBase = () => {
    setImageModel(outputImage);
    setItems([
      { id: 1, image: null, label: '' },
      { id: 2, image: null, label: '' }
    ]);
    setOutputImage(null);
  };

  return (
    <div className="h-screen w-full bg-stone-50 text-stone-900 font-sans p-4 flex flex-col overflow-hidden">
      <header className="text-center space-y-1 mb-4 shrink-0">
        <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-stone-900">Inpainting Studio</h1>
        <p className="text-stone-500 text-sm">Chỉnh sửa cộng dồn - Thêm trang phục & phụ kiện</p>
      </header>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-4 min-h-0 max-w-[1600px] mx-auto w-full">
        
        {/* Left Column: Items (col-span-3) */}
        <div className="lg:col-span-3 flex flex-col h-full min-h-0">
          <div className="bg-white p-4 rounded-2xl shadow-sm border border-stone-200 flex-1 flex flex-col gap-4 min-h-0">
            <h2 className="text-sm font-bold text-stone-800 uppercase tracking-wider flex items-center gap-2 shrink-0">
              <Plus className="w-4 h-4" />
              Vật phẩm mới
            </h2>
            <div className="flex-1 flex flex-col gap-4 min-h-0 overflow-y-auto pr-1">
              {items.map((item, index) => (
                <div key={item.id} className="bg-stone-50 p-3 rounded-xl border border-stone-100 flex-1 flex flex-col min-h-0 gap-2">
                  <div 
                    className="relative border-2 border-dashed border-stone-200 rounded-lg flex-1 flex flex-col items-center justify-center bg-white overflow-hidden group cursor-pointer hover:border-stone-400 transition-all min-h-0"
                    onClick={() => !item.image && fileInputItemRefs.current[index]?.click()}
                  >
                    {item.image ? (
                      <>
                        <img src={item.image} alt={`Item ${item.id}`} className="absolute inset-0 w-full h-full object-contain p-2 bg-white" />
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            handleRemoveItem(index);
                          }}
                          className="absolute top-2 right-2 p-1.5 bg-white/90 backdrop-blur-sm rounded-full shadow-md text-red-500 hover:bg-red-50 hover:text-red-600 transition-colors z-10"
                          title="Xóa ảnh này"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </>
                    ) : (
                      <div className="text-center p-2 transition-transform group-hover:scale-105">
                        <Plus className="w-6 h-6 text-stone-400 mx-auto mb-1" />
                        <p className="text-xs font-medium text-stone-500">Item {item.id}</p>
                      </div>
                    )}
                    <input 
                      type="file" 
                      accept="image/*" 
                      className="hidden" 
                      ref={el => fileInputItemRefs.current[index] = el}
                      onChange={(e) => handleItemFileChange(index, e)}
                    />
                  </div>
                  
                  <input 
                    type="text" 
                    value={item.label}
                    onChange={(e) => handleLabelChange(index, e.target.value)}
                    placeholder="Nhập câu lệnh AI (VD: Thay váy trắng này vào...)"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-stone-200 focus:ring-0 focus:border-stone-800 outline-none transition-colors bg-white shrink-0"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Middle Column: Base Image & Generate (col-span-4) */}
        <div className="lg:col-span-4 flex flex-col h-full min-h-0 gap-4">
          <div className="bg-white p-4 rounded-2xl shadow-sm border border-stone-200 flex-1 flex flex-col min-h-0">
            <h2 className="text-sm font-bold text-stone-800 uppercase tracking-wider flex items-center gap-2 mb-3 shrink-0">
              <ImageIcon className="w-4 h-4" />
              Ảnh người mẫu gốc
            </h2>
            <div 
              className="relative border-2 border-dashed border-stone-300 rounded-xl flex-1 flex flex-col items-center justify-center bg-stone-50 overflow-hidden group cursor-pointer hover:border-stone-500 transition-all min-h-0"
              onClick={() => fileInputModelRef.current?.click()}
            >
              {imageModel ? (
                <img src={imageModel} alt="Model" className="absolute inset-0 w-full h-full object-contain" />
              ) : (
                <div className="text-center p-6 transition-transform group-hover:scale-105">
                  <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mx-auto mb-3 shadow-sm">
                    <Upload className="w-6 h-6 text-stone-500" />
                  </div>
                  <p className="text-sm font-medium text-stone-700">Tải ảnh người mẫu</p>
                  <p className="text-xs text-stone-400 mt-1">PNG, JPG</p>
                </div>
              )}
              <input 
                type="file" 
                accept="image/*" 
                className="hidden" 
                ref={fileInputModelRef}
                onChange={handleModelFileChange}
              />
            </div>
          </div>
          
          <div className="shrink-0">
            {error && (
              <div className="p-3 mb-3 bg-red-50 border border-red-100 text-red-700 rounded-xl text-xs font-medium text-center">
                {error}
              </div>
            )}
            <button
              onClick={handleGenerate}
              disabled={isLoading}
              className="w-full py-4 bg-stone-900 text-white rounded-xl font-bold text-base hover:bg-stone-800 disabled:bg-stone-400 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2 shadow-md hover:shadow-lg active:scale-[0.99]"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Đang xử lý ảnh...
                </>
              ) : (
                <>
                  Bắt đầu thử đồ
                  <ArrowRight className="w-5 h-5" />
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Output & Next Base (col-span-5) */}
        <div className="lg:col-span-5 flex flex-col h-full min-h-0 gap-4">
          <div className="bg-white p-4 rounded-2xl shadow-sm border border-stone-200 flex-1 flex flex-col min-h-0">
            <h2 className="text-sm font-bold text-stone-800 uppercase tracking-wider flex items-center gap-2 mb-3 shrink-0">
              <ImageIcon className="w-4 h-4" />
              Kết quả
            </h2>
            <div className="relative border-2 border-stone-100 rounded-xl flex-1 flex flex-col items-center justify-center bg-stone-50 overflow-hidden min-h-0">
              {outputImage ? (
                <img src={outputImage} alt="Output" className="absolute inset-0 w-full h-full object-contain" />
              ) : (
                <div className="text-stone-400 text-sm flex flex-col items-center gap-2">
                  <ImageIcon className="w-8 h-8 opacity-20" />
                  <span>Ảnh kết quả sẽ hiển thị ở đây</span>
                </div>
              )}
            </div>
          </div>
          
          <div className="shrink-0">
            <button
              onClick={handleUseAsNextBase}
              disabled={!outputImage || isLoading}
              className="w-full py-4 bg-[#FF6321] text-white rounded-xl font-bold text-base hover:bg-[#e5581d] disabled:bg-stone-300 disabled:text-stone-500 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2 shadow-md hover:shadow-lg active:scale-[0.99]"
            >
              <RefreshCw className="w-5 h-5" />
              DÙNG ẢNH NÀY LÀM ẢNH GỐC TIẾP THEO
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
